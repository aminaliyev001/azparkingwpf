﻿using Final.Pages;
using Final.Services;
using Final.ViewModels;
using Final.ViewModels.SettingsViewModels;
using System.Configuration;
using System.Data;
using System.Windows;
using System.Windows.Threading;
using static Final.ViewModels.MainWindowViewModel;

namespace Final
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static ServiceLocator ServiceLocator { get; private set; }
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            ServiceLocator = new ServiceLocator();
            ServiceLocator.RegisterService(new SettingsViewModel());
            ServiceLocator.RegisterService(new ParkingViewModel());
            ServiceLocator.RegisterService(new MainWindowViewModel());
            ServiceLocator.RegisterService(new MapViewModel());
            ServiceLocator.RegisterService(new TimeViewModel());
            ServiceLocator.RegisterService(new SupportViewModel()); 
            ServiceLocator.RegisterService(new InformationViewModel());
            ServiceLocator.RegisterService(new CarViewModel()); 
            ServiceLocator.RegisterService(new AddCarViewModel());
            ServiceLocator.RegisterService(new RentParkingViewModel());
        }
        private void Application_Startup(object sender, StartupEventArgs e)
        {
            Loading loadingWindow = new Loading();
            loadingWindow.Show();

            Task.Delay(3000).ContinueWith(_ =>
            {
                Dispatcher.Invoke(() =>
                {
                    MainWindowViewModel mainWindowViewModel = ServiceLocator.GetService<MainWindowViewModel>();
                    MainWindow mainWindow = new MainWindow
                    {
                        DataContext = mainWindowViewModel
                    };
                    mainWindow.Show();
                    loadingWindow.Close();
                });
            });
        }
    }
}
