﻿using System.Collections.ObjectModel;
using System.Text.RegularExpressions;
using System.Windows;

namespace Final.Models;
public class Car : BaseModel
{
    public override string ToString()
    {
        return PlateNumber.ToString();
    }
    public Car() { }
    private bool IsValidPlateNumber(string number)
    {
        var regex = new Regex(@"^\d{2}[A-Z]{2}\d{3}$");
        return regex.IsMatch(number);
    }
    private string? _plateNumber;
    public string PlateNumber { get => _plateNumber; set { if (IsValidPlateNumber(value)) { _plateNumber = value; OnPropertyChanged(nameof(PlateNumber)); } else { MessageBox.Show("Qeydiyyat nişanı düzgün daxil edilməyib: 01AA123"); } } }
}
public class UserProfile : BaseModel
{
    public UserProfile() { 
    }    
    private bool IsValidPhoneNumber(string number)
    {
        var regex = new Regex(@"^\d{12}$");
        return regex.IsMatch(number);
    }
    private string? _name;
    public string Name { get => _name; set { _name = value; OnPropertyChanged(nameof(Name)); } }
    private string? _surname;
    public string Surname { get => _surname; set { _surname = value; OnPropertyChanged(nameof(Surname)); } }
    private string _phoneNumber;
    public string PhoneNumber { get => _phoneNumber; set { if (IsValidPhoneNumber(value)) { _phoneNumber = value; OnPropertyChanged(nameof(PhoneNumber)); } else { MessageBox.Show("Telefon nömrəsini düzgün formada daxil edin: 994123456789"); } } }
    public ObservableCollection<Car> Cars { get; set; } = new ObservableCollection<Car>();

    private double _balance;
    public double Balance { get => _balance; set { _balance = value;OnPropertyChanged(nameof(Balance)); } }
    public UserProfile ShallowCopy()
    {
        return (UserProfile)this.MemberwiseClone();
    }
}
