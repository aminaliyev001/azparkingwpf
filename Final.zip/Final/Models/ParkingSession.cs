﻿namespace Final.Models;
public class ParkingSession : BaseModel
{
    private ParkingPlace? _parking;
    public ParkingPlace _Parking { get => _parking; set { _parking = value;OnPropertyChanged(nameof(_Parking)); }}
    private DateTime _datetime;
    public DateTime _Datetime
    {
        get => _datetime;
        set
        {
                _datetime = value;
                OnPropertyChanged(nameof(_Datetime));
        }
    }
    private Car? _car;
    public Car _Car { get => _car; set { _car = value; OnPropertyChanged(nameof(_Car));}}
    public ParkingSession() { }
}
