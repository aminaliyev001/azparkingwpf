﻿using Microsoft.Maps.MapControl.WPF;
using System.ComponentModel;
using System.Text.Json.Serialization;
using System.Windows;
using System.Xml.Linq;

namespace Final.Models;
public class BaseModel : INotifyPropertyChanged
{
    private string? id;
    public string Id { get => id; set { id = value; OnPropertyChanged(nameof(Id)); } }
    public event PropertyChangedEventHandler PropertyChanged;
    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
    public BaseModel() { }
}
public class Coordinate
{
    public Coordinate() { }
    public double Lang
    {
        get;set;
    }

    public double Long
    {
        get;set;
    }
}

public class ParkingPlace : BaseModel
{
    public ParkingPlace() { }
    public string StreetName { get; set; }
    public string ParkingPin { get; set; }
    public decimal Price { get; set; }
    public decimal Distance { get; set; }
    public Coordinate? _Coordinate { get; set; }
    public int AvailablePlaces { get; set; }
    public int Capacity { get; set; }


}
