﻿using Final.Models;
using Final.Pages;
using MaterialDesignThemes.Wpf;
using Microsoft.Maps.MapControl.WPF;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Security.Policy;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
namespace Final.ViewModels;
    public class MapViewModel : BaseViewModel
    {
    public ICommand WazeCommand { get; set; }
    public ICommand CloseCommand { get; set; }
    public ICommand DetailCommand { get; set; }
    private string _gridV;
    public string GridVisibiility { get => _gridV; set { _gridV = value;OnPropertyChanged(nameof(GridVisibiility)); }}
    private string _wazebtnVisibility;
    public string WazeButtonVisibility { get => _wazebtnVisibility; set { _wazebtnVisibility = value; OnPropertyChanged(nameof(WazeButtonVisibility)); } }
    private string WazeLink = "https://waze.com";
    public ObservableCollection<ParkingPlace>? SelectedParkingPlace { get; set; }
    public MapViewModel()
    {
        SelectedParkingPlace = new ObservableCollection<ParkingPlace>();
    }
    private Pages.Map _view;
    public object View
    {
        get
        {
            if (_view == null)
            {
                var mapPage = new Pages.Map { DataContext = this };
                _view = mapPage;
                AddPinsToMap(mapPage.MapBing);
                GridVisibiility = "Hidden";
                WazeCommand = new RelayCommand(wazeBtnClick);
                DetailCommand = new RelayCommand(DetailPopup);
                CloseCommand = new RelayCommand(closePopup);
                WazeButtonVisibility = "Collapsed";
            }
            return _view;
        }
    }
    private void AddPinsToMap(Microsoft.Maps.MapControl.WPF.Map mapControl)
    {
        foreach (var parkingPlace in AllParkings) 
        {
            var pin = new Pushpin
            {
                Location = new Location(parkingPlace._Coordinate.Lang, parkingPlace._Coordinate.Long)
            };
            pin.MouseLeftButtonDown += CustomButton_Click;
            mapControl.Children.Add(pin);
        }
    }
    private void findParking(Pushpin pushp)
    {
        foreach(var p in AllParkings)
        {
            if(p._Coordinate.Lang == pushp.Location.Latitude && p._Coordinate.Long == pushp.Location.Longitude)
            {
                SelectedParkingPlace.Clear();
                SelectedParkingPlace.Add(p);
                return;
            }
        }
    }
    private void CustomButton_Click(object sender, RoutedEventArgs e)
    {
        WazeButtonVisibility = "Visible";
        var clickedPushpin = sender as Pushpin;
        WazeLink = "https://www.waze.com/en/live-map/directions?latlng=" + clickedPushpin.Location.Latitude + "%2C" + clickedPushpin.Location.Longitude;
        findParking(clickedPushpin);
        GridVisibiility = "Visible";
    }
    private void closePopup()
    {
        GridVisibiility = "Collapsed";
        WazeButtonVisibility = "Collapsed";
    }
    private void DetailPopup()
    {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<RentParkingViewModel>();
        newPage.Initialize(SelectedParkingPlace[0].ParkingPin);
        mainWindowViewModel?.ChangeCurrentPage(newPage.View);
    }
    private void wazeBtnClick()
    {
        System.Diagnostics.Process.Start(new ProcessStartInfo
        {
            FileName = "cmd",
            RedirectStandardInput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        }).StandardInput.WriteLine("start " + WazeLink);
    }
}
