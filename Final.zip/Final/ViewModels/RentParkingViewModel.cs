﻿using Final.Pages.SettingsPages;
using Final.Pages;
using System.Windows.Input;
using Final.Models;
using System.Windows;
using System.IO;
using System.Text.Json;
namespace Final.ViewModels;
public class RentParkingViewModel : BaseViewModel
{
    public const string CurrentParkingFile = "CurrentParking.json";
    public ICommand? SaveCommand {  get; set; }
    private RentParking? _view;
    private Car _selectedCar;
    public ParkingSession? _parkingsession { get; set; }

    public Car SelectedCar
    {
        get => _selectedCar;
        set
        {
            _selectedCar = value;
            OnPropertyChanged(nameof(SelectedCar));
        }
    }
    public RentParkingViewModel()
    {
        SaveCommand = new RelayCommand(startRenting);
        _parkingsession = new ParkingSession();
    }
    public object View
    {
        get
        {
            if (_view == null)
            {
                _view = new RentParking { DataContext = this };
            }
            return _view;
        }
    }
    public void Initialize(string parkingpin)
    {
       foreach(var parking in AllParkings) { 
       if(parking.ParkingPin == parkingpin)
            {
                _ParkingPlace = parking;
                break;
            }
        }
    }
    public bool ParkingActive()
    {
        string workingDirectory = Environment.CurrentDirectory;
        string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
        if (!File.Exists(projectDirectory2+"/Database/"+ CurrentParkingFile))
        {
            return true;
        }

        string content = File.ReadAllText(projectDirectory2 + "/Database/" + CurrentParkingFile);
        return !(string.IsNullOrWhiteSpace(content));
    }
    public void startRenting()
    {
        if(!ParkingActive())
        {
            if (SelectedCar != null)
            {
                try
                {
                    string workingDirectory = Environment.CurrentDirectory;
                    string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
                    DateTime currentDateTime = DateTime.Now;
                    _parkingsession.Id = Guid.NewGuid().ToString();
                    _parkingsession._Car = SelectedCar;
                    _parkingsession._Parking = _ParkingPlace;
                    _parkingsession._Datetime = currentDateTime;
                    string jsonString = JsonSerializer.Serialize(_parkingsession, new JsonSerializerOptions { WriteIndented = true });
                    File.WriteAllText(projectDirectory2 + "/Database/" + CurrentParkingFile, jsonString);
                    toParking();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                    Clipboard.SetText(ex.Message);
                }
            } else
            {
                MessageBox.Show("Avtomobil secmediniz");
            }
            
        } else
        {
            MessageBox.Show("Hal hazırda parkinq aktivdir");
        }
    }
    public void toParking()
    {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<ParkingViewModel>();
        mainWindowViewModel?.ChangeCurrentPage(newPage.View);
    }
    private ParkingPlace? _parkingPlace;
    public ParkingPlace _ParkingPlace { get => _parkingPlace; set { _parkingPlace = value; OnPropertyChanged(nameof(_ParkingPlace)); }}
}
