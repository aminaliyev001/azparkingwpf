﻿using Final.Models;
using Final.Pages;
using System.Text.Json;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Windows;
namespace Final.ViewModels;
public class BaseViewModel : INotifyPropertyChanged
{

    public const string fileName = "Parkings.json";
    private const string UserFileName = "UserProfile.json";
    public event PropertyChangedEventHandler PropertyChanged;
    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
    public List<ParkingPlace>? AllParkings { get; set; }
    public ObservableCollection<ParkingPlace>? Parkings { get; set; }
    private UserProfile? _userprofile;
    public UserProfile _UserProfile { get => _userprofile; set { _userprofile = value; OnPropertyChanged(nameof(_UserProfile));}}
    public void loadParkings()
    {
        string workingDirectory = Environment.CurrentDirectory;
        string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;

        string filePath = projectDirectory2+"/Database/" + fileName;
        string json = File.ReadAllText(filePath);
        var parkingList = JsonSerializer.Deserialize<List<ParkingPlace>>(json);
        if (parkingList != null)
        {
            foreach (var parking in parkingList)
            {
                Parkings.Add(parking);
                AllParkings.Add(parking);
            }
        }
    }
    public void loadUserProfile()
    {
        string workingDirectory = Environment.CurrentDirectory;
        string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;

        string filePath = projectDirectory2+"/Database/" + UserFileName;
        string json = File.ReadAllText(filePath);
        var _userp = JsonSerializer.Deserialize<UserProfile>(json);
        if (_userp != null)
        {
            _UserProfile = _userp;
        }
    }
    public void SaveUserProfile()
    {
        try
        {
            string workingDirectory = Environment.CurrentDirectory;
            string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;

            string filePath = projectDirectory2 + "/Database/" + UserFileName;
            string json = JsonSerializer.Serialize(_UserProfile, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(filePath, json);
        }
        catch (Exception ex)
        {
            MessageBox.Show("error bas verdi: " + ex.Message);
        }
    }
    public BaseViewModel() {
        Parkings = new ObservableCollection<ParkingPlace>();
        AllParkings = new List<ParkingPlace>();
        loadParkings();
        loadUserProfile();
    }
}
