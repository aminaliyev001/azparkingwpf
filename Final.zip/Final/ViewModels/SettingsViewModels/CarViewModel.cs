﻿using Final.Models;
using Final.Pages.SettingsPages;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;

namespace Final.ViewModels.SettingsViewModels;
public class CarViewModel : BaseViewModel
{
    public ICommand AddCarCommand { get; set; } 
    public ICommand GoBackCommand { get; set; }
    private CarsPage _view;
    public object View
    {
        get
        {
            if (_view == null)
            {
                _view = new CarsPage { DataContext = this };
                GoBackCommand = new RelayCommand(toBack);
                AddCarCommand = new RelayCommand(ToAddCar);
            }
            return _view;
        }
    }
    public void toBack()
    {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<SettingsViewModel>().View;
        mainWindowViewModel?.ChangeCurrentPage(newPage);
    }
    public void ToAddCar()
    {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<AddCarViewModel>().View;
        mainWindowViewModel?.ChangeCurrentPage(newPage);
    }
}
