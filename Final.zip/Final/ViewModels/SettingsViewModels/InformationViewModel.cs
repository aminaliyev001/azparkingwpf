﻿using Final.Pages.SettingsPages;
using Final.Pages;
using System.Collections.ObjectModel;
using Final.Models;
using System.Windows.Input;
using System.Windows;

namespace Final.ViewModels.SettingsViewModels;

public class InformationViewModel : BaseViewModel
{
    private InformationPage _view;
    public object View
    {
        get
        {
            if (_view == null)
            {
                _view = new InformationPage { DataContext = this };
                CurrentUser = _UserProfile.ShallowCopy();
                SaveCommand = new RelayCommand(ExecuteSave, canSave);
                GoBackCommand = new RelayCommand(toBack);
            }
            return _view;
        }
    }
    public ICommand SaveCommand { get; private set; }
    public ICommand GoBackCommand { get; private set; }
    private UserProfile _currentUser;
    public UserProfile CurrentUser
    {
        get => _currentUser;
        set
        {
            _currentUser = value;
            OnPropertyChanged(nameof(CurrentUser));
        }
    }
    public bool canSave()
    {
        return !string.IsNullOrWhiteSpace(CurrentUser.Name) && !string.IsNullOrWhiteSpace(CurrentUser.Surname) && CurrentUser.PhoneNumber?.Length == 12;
    }
    public void ExecuteSave()
    {
        _UserProfile = CurrentUser;
        SaveUserProfile();
        toBack();
    }
    public void toBack() {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<SettingsViewModel>().View;
        mainWindowViewModel?.ChangeCurrentPage(newPage);
    }
}
