﻿using Final.Pages.SettingsPages;
using Final.Pages;
using System.Windows.Input;
using System.Diagnostics;
using System.Windows.Shapes;

namespace Final.ViewModels.SettingsViewModels;
public class SupportViewModel : BaseViewModel
{
    public ICommand? MailCommand { get; set; }
    public ICommand? FacebookCommand { get; set; }
    public ICommand? InstagramCommand { get; set; }
    private SupportPage _view;
    public object View
    {
        get
        {
            if (_view == null)
            {
                _view = new SupportPage { DataContext = this };
                MailCommand = new RelayCommand(MailLink);
                FacebookCommand = new RelayCommand(FacebookLink);
                InstagramCommand = new RelayCommand(InstagramLink);

            }
            return _view;
        }
    }
    public void InstagramLink()
    {
        string link = "https://instagram.com/azparking.az";
        System.Diagnostics.Process.Start(new ProcessStartInfo
        {
            FileName = "cmd",
            RedirectStandardInput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        }).StandardInput.WriteLine("start " + link);
    }
    public void FacebookLink()
    {
        string link = "https://facebook.com/azparking.az";
        System.Diagnostics.Process.Start(new ProcessStartInfo
        {
            FileName = "cmd",
            RedirectStandardInput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        }).StandardInput.WriteLine("start " + link);
    }
    public void MailLink()
    {
        var email = "parking@ayna.gov.az";
        var mailtoUrl = $"mailto:{email}";
        System.Diagnostics.Process.Start(new ProcessStartInfo
        {
            FileName = "cmd",
            RedirectStandardInput = true,
            UseShellExecute = false,
            CreateNoWindow = true
        }).StandardInput.WriteLine("start " + mailtoUrl);
    }
}
