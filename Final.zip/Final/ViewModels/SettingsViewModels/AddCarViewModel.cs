﻿using Final.Pages.SettingsPages;
using Final.Pages;
using System.Windows.Input;
using Final.Models;
using System.Windows;
namespace Final.ViewModels.SettingsViewModels;
public class AddCarViewModel : BaseViewModel
{
    private Car? _car;
    public Car _CurrentCar { get => _car; set { _car = value; OnPropertyChanged(nameof(_CurrentCar)); }}
    private AddCar _view;
    public object View
    {
        get
        {
            if (_view == null)
            {
                _view = new AddCar { DataContext = this };
                SaveCommand = new RelayCommand(SaveCar);
                GoBackCommand = new RelayCommand(toBack);
                _CurrentCar = new Car();
            }
            return _view;
        }
    }
    public ICommand GoBackCommand { get; set; }
    public ICommand SaveCommand { get; set; }
    public void SaveCar()
    {
        _CurrentCar.Id = Guid.NewGuid().ToString();
        _UserProfile.Cars.Add(_CurrentCar);
        SaveUserProfile();
        _CurrentCar = null;
        toBack();
    }
    public void toBack()
    {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<CarViewModel>().View;
        mainWindowViewModel?.ChangeCurrentPage(newPage);
    }
}
