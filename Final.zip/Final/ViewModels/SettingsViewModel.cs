﻿using Final.Pages;
using System.Configuration;
using System.Windows;
using System.Windows.Input;
using Final.ViewModels.SettingsViewModels;
namespace Final.ViewModels;
    public class SettingsViewModel:BaseViewModel {
    private Settings _view;
    public ICommand? ProfileCommand { get; set; }
    public ICommand? InformationCommand {  get; set; }  
    public ICommand? CarsCommand { get; set; }
    public object View
    {
        get
        {
            if (_view == null)
            {
                _view = new Settings { DataContext = this };
            }
            ProfileCommand = new RelayCommand(ToSupportPage);
            InformationCommand = new RelayCommand(ToInformationPage);
            CarsCommand = new RelayCommand(ToCarsPage);
            return _view;
        }
    }
    public void ToSupportPage()
    {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<SupportViewModel>().View;
        mainWindowViewModel?.ChangeCurrentPage(newPage);
    }
    public void ToInformationPage()
    {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<InformationViewModel>().View;
        mainWindowViewModel?.ChangeCurrentPage(newPage);
    }
    public void ToCarsPage()
    {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<CarViewModel>().View;
        mainWindowViewModel?.ChangeCurrentPage(newPage);
    }
}
