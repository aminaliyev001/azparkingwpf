﻿using Final.Models;
using Final.Pages;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
namespace Final.ViewModels;
public class TimeViewModel : BaseViewModel
{
    private FileSystemWatcher _fileWatcher;
    private TimeSpan _timeDifference;
    private DispatcherTimer _timer;
    public int Days => _timeDifference.Days;
    public int Hours => _timeDifference.Hours;
    public int Minutes => _timeDifference.Minutes;
    public int Seconds => _timeDifference.Seconds;

    public ICommand? PayCommand { get; set; }
    public const string filePath = "CurrentParking.json";

    private bool _isActiveParking;
    public bool IsActiveParking
    {
        get => _isActiveParking;
        set
        {
            _isActiveParking = value;
            OnPropertyChanged(nameof(IsActiveParking));
        }
    }
    private string? notfoundImagePath;
    public string? NotFoundImagePath { get => notfoundImagePath; set { notfoundImagePath = value; OnPropertyChanged(nameof(NotFoundImagePath)); }}
    public ParkingSession? _SessionParking { get; set; }
    
    private Time _view;
    public object View
    {
        get
        {
            if (_view == null)
            {
                _view = new Time { DataContext = this };
            }
            return _view;
        }
    }
    private void InitializeFileWatcher()
    {
        string workingDirectory = Environment.CurrentDirectory;
        string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
        _fileWatcher = new FileSystemWatcher
        {
            Path = Path.GetDirectoryName(projectDirectory2 + "/Database/" + filePath),
            Filter = Path.GetFileName(projectDirectory2 + "/Database/" + filePath),
            NotifyFilter = NotifyFilters.LastWrite
        };

        _fileWatcher.Changed += OnJsonFileChanged;
        _fileWatcher.EnableRaisingEvents = true;
    }

    private void OnJsonFileChanged(object sender, FileSystemEventArgs e)
    {
        Application.Current.Dispatcher.Invoke(LoadParkingData);
    }
    private void StartTimer()
    {
        _timer = new DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(1)
        };
        _timer.Tick += Timer_Tick;
        _timer.Start();
    }

    private void Timer_Tick(object sender, EventArgs e)
    {
        if (_SessionParking?._Datetime != null)
        {
            _timeDifference = DateTime.Now - _SessionParking._Datetime;
            OnPropertyChanged(nameof(Days));
            OnPropertyChanged(nameof(Hours));
            OnPropertyChanged(nameof(Minutes));
            OnPropertyChanged(nameof(Seconds));
        }
    }
    public TimeViewModel()
    {
        string workingDirectory = Environment.CurrentDirectory;
        string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
        LoadParkingData();
        NotFoundImagePath = projectDirectory2 + "/Assets/" + "notfound.jpg";
        PayCommand = new RelayCommand(StopAndPay);
        InitializeFileWatcher();
    }
    public bool ParkingActive()
    {
        string workingDirectory = Environment.CurrentDirectory;
        string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
        if (!File.Exists(projectDirectory2 + "/Database/" + filePath))
        {
            return true;
        }
        string content = File.ReadAllText(projectDirectory2 + "/Database/" + filePath);
        return !(string.IsNullOrWhiteSpace(content));
    }
    public void LoadParkingData()
    {
        string workingDirectory = Environment.CurrentDirectory;
        string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
        try
        {
            if (File.Exists(projectDirectory2 + "/Database/" + filePath) && ParkingActive())
            {
                string jsonString = File.ReadAllText(projectDirectory2 + "/Database/" + filePath);
                _SessionParking = JsonSerializer.Deserialize<ParkingSession>(jsonString);
                IsActiveParking = true;
                StartTimer();
            }
            else
            {
                IsActiveParking = false;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
        }
    }
    public void EndCurrentParking()
    {
        string workingDirectory = Environment.CurrentDirectory;
        string projectDirectory2 = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
        File.WriteAllText(projectDirectory2 + "/Database/" + filePath, "");
    }
    public void StopAndPay()
    {
        DateTime currentDateTime = DateTime.Now;
        TimeSpan duration = currentDateTime - _SessionParking._Datetime;
        double price = (double)_SessionParking._Parking.Price;
        decimal FinalPaidPrice = 0;
        if (duration.TotalMinutes > 15)
        {
            FinalPaidPrice = (decimal)(Math.Ceiling((duration.TotalMinutes - 15) / 60) * price);
        }
        _UserProfile.Balance -= (double)FinalPaidPrice;
        SaveUserProfile();
        MessageBox.Show("Yekun ödənilən məbləğ: " + FinalPaidPrice);
        EndCurrentParking();
        _timer.Stop();
        IsActiveParking = false;
    }
    public void Dispose()
    {
        if (_fileWatcher != null)
        {
            _fileWatcher.Changed -= OnJsonFileChanged;
            _fileWatcher.Dispose();
        }
    }
}
