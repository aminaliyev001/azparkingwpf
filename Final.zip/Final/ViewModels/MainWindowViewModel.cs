﻿using Final.Pages;
using MaterialDesignColors;
using Microsoft.Maps.MapControl.WPF;
using System.ComponentModel;
using System.Configuration;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace Final.ViewModels;
public class MainWindowViewModel : BaseViewModel
    {
    private object _currentPage;
    public void changeStyleButton(ButtonControl o)
    {
        o.BackgroundColor = ((SolidColorBrush)Application.Current.Resources["PrimaryColor"]).Color.ToString();
        o.ForegroundColor = ((SolidColorBrush)Application.Current.Resources["WhiteColor"]).Color.ToString();
    }
    public void resetStyleButton(ButtonControl b)
    {
        b.BackgroundColor = ((SolidColorBrush)Application.Current.Resources["WhiteColor"]).Color.ToString();
        b.ForegroundColor = "Gray";
    }
    private ButtonControl _parkingControl = new ButtonControl();
    public ButtonControl ParkingControl_ {
        get => _parkingControl;
        set
        {
            _parkingControl = value;
            OnPropertyChanged(nameof(ParkingControl_));
        }
    }
    public ButtonControl _mapControl  = new ButtonControl();
    public ButtonControl MapControl_
    {
        get => _mapControl;
        set
        {
            _mapControl = value;
            OnPropertyChanged(nameof(MapControl_));
        }
    }
    public ButtonControl _timeControl  = new ButtonControl();
    public ButtonControl TimeControl_
    {
        get => _timeControl;
        set
        {
            _timeControl = value;
            OnPropertyChanged(nameof(TimeControl_));
        }
    }
    public ButtonControl _profileControl = new ButtonControl();
    public ButtonControl ProfileControl_
    {
        get => _profileControl;
        set
        {
            _profileControl = value;
            OnPropertyChanged(nameof(ProfileControl_));
        }
    }
    public object CurrentPage
    {
        get => _currentPage;
        set
        {
            _currentPage = value;
            OnPropertyChanged(nameof(CurrentPage));
        }
    }
    public ButtonControl CurrentActiveButton { get; set; }
    public void ToTimeMenu()
    {
        CurrentPage = App.ServiceLocator.GetService<TimeViewModel>().View;
        changeStyleButton(TimeControl_);
        resetStyleButton(CurrentActiveButton);
        CurrentActiveButton = _timeControl;
    }
    public void ToMapMenu()
    {
        if (CurrentActiveButton != MapControl_)
        {
            CurrentPage = App.ServiceLocator.GetService<MapViewModel>().View;
            changeStyleButton(MapControl_);
            resetStyleButton(CurrentActiveButton);
            CurrentActiveButton = _mapControl;
        }
    }
    public void ToProfileMenu()
    {
        CurrentPage = App.ServiceLocator.GetService<SettingsViewModel>().View;
        if (CurrentActiveButton != ProfileControl_)
        {
            changeStyleButton(ProfileControl_);
            resetStyleButton(CurrentActiveButton);
            CurrentActiveButton = _profileControl;
        }
    }
    public void ToParkingMenu()
    {
        CurrentPage = App.ServiceLocator.GetService<ParkingViewModel>().View;
        changeStyleButton(ParkingControl_);
        resetStyleButton(CurrentActiveButton);
        CurrentActiveButton = _parkingControl;
    }
    public void ChangeCurrentPage(object newPage)
    {
        CurrentPage = newPage;
    }
    public MainWindowViewModel()
        {
        ProfileControl_.NavigateCommand = new RelayCommand(ToProfileMenu);
        ParkingControl_.NavigateCommand = new RelayCommand(ToParkingMenu);
        changeStyleButton(_parkingControl);
        TimeControl_.NavigateCommand = new RelayCommand(ToTimeMenu);
        MapControl_.NavigateCommand = new RelayCommand(ToMapMenu);
        CurrentPage = App.ServiceLocator.GetService<ParkingViewModel>().View;
        CurrentActiveButton = _parkingControl;
    }
    public class ButtonControl : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        public ICommand NavigateCommand { get; set; }
        private string? _backgroundColor { get; set; }
        public string BackgroundColor
        {
            get => _backgroundColor;
            set
            {
                _backgroundColor = value;
                OnPropertyChanged(nameof(BackgroundColor));
            }
        }
        private string? _foregroundColor { get; set; }
        public string ForegroundColor
        {
            get => _foregroundColor;
            set
            {
                _foregroundColor = value;
                OnPropertyChanged(nameof(ForegroundColor));
            }
        }
        public ButtonControl()
        {
            ForegroundColor = "Gray";
            BackgroundColor = "#fff";
        }
    }
}
