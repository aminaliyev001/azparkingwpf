﻿using Final.Pages;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Windows;
using Final.Models;
using System.Windows.Input;
namespace Final.ViewModels;
public class ParkingViewModel : BaseViewModel
{

    public static string fileName = "Parkings.json";
    public ICommand? GoToParking {  get; set; }
    private Parking? _view;
    public ParkingViewModel()
    {
        GoToParking = new RelayCommand2<string>(ToRentParking);
    }
    public object View
    {
        get
        {
            if (_view == null)
            {
                _view = new Parking { DataContext = this };
            }
            return _view;
        }
    }
    private string _filter;
    public string Filter
    {
        get => _filter;
        set
        {
            _filter = value;
            OnPropertyChanged(nameof(Filter));
            FilterParkings();
        }
    }
    public void FilterParkings()
    {
        if (string.IsNullOrEmpty(Filter))
        {
            foreach (var parking in AllParkings)
            {
                if (!Parkings.Contains(parking))
                    Parkings.Add(parking);
            }
        }
        else
        {
            var filteredList = Parkings.Where(parking => parking.StreetName.Contains(Filter) || parking.ParkingPin.Contains(Filter)).ToList();
            Parkings.Clear();
            foreach (var parking in filteredList)
            {
                Parkings.Add(parking);
            }
        }
    }
    private void ToRentParking(string par)
    {
        var mainWindowViewModel = App.ServiceLocator.GetService<MainWindowViewModel>();
        var newPage = App.ServiceLocator.GetService<RentParkingViewModel>();
        newPage.Initialize(par);
        mainWindowViewModel?.ChangeCurrentPage(newPage.View);
    }
}
